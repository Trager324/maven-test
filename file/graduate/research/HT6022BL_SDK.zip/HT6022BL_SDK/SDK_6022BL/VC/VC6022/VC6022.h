// VC6022.h : main header file for the VC6022 application
//

#if !defined(AFX_VC6022_H__67446194_A6F0_4059_8E4C_61C5D20D3432__INCLUDED_)
#define AFX_VC6022_H__67446194_A6F0_4059_8E4C_61C5D20D3432__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CVC6022App:
// See VC6022.cpp for the implementation of this class
//

class CVC6022App : public CWinApp
{
public:
	CVC6022App();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CVC6022App)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CVC6022App)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_VC6022_H__67446194_A6F0_4059_8E4C_61C5D20D3432__INCLUDED_)
